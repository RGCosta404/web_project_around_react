export default function Footer() {
  return (
    <footer className="footer">
        <p className="footer__copyright">&copy; 2025 Around The U.S.</p>
      </footer>
  );
}